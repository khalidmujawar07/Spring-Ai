package com.springai.Spring_Ai;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.springai.Spring_Ai.payload.CricketResponse;
import com.springai.Spring_Ai.service.ChatService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.util.Map;

@SpringBootTest
class SpringAiApplicationTests {

	@Autowired
	private ChatService chatService;

	@Test
	void testResponse() throws JsonProcessingException {
		CricketResponse cricketResponse = chatService.generateCricketResponse("Who is sachin?");
		System.out.println(cricketResponse);
	}

	@Test
	void testTemplate() throws IOException {
		String s = chatService.loadPromptTemplate("prompts/cricket_bot.txt");
		String prompt = chatService.putValuesInPromptTemplate(s, Map.of("inputText", "what is cricket?"));
		System.out.println(prompt);;
	}

}

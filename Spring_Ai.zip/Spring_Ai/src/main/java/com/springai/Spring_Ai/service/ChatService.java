package com.springai.Spring_Ai.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.springai.Spring_Ai.payload.CricketResponse;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.StreamingChatModel;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.image.*;
import org.springframework.ai.openai.OpenAiImageOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ChatService {

    @Autowired
    private ChatModel chatModel;

    @Autowired
    private ImageModel imageModel;

    @Autowired
    private StreamingChatModel streamingChatModel;

    /**
     * Basic text generation using the AI model
     */
    public String generateResponse(String inputText) {
        return chatModel.call(inputText); // Simple call without prompt
    }

    /**
     * Streamed AI response using Flux
     */
    public Flux<String> streamResponse(String inputText) {
        return chatModel.stream(inputText); // For SSE or streaming output
    }

    /**
     * Cricket-specific response formatted as JSON and mapped to a Java object
     */
    public CricketResponse generateCricketResponse(String inputText) throws JsonProcessingException {
        // Define the prompt asking to reply in JSON format
        String promptString = "As a cricket expert, answer this question: " + inputText + ". "
                + "If the question is not related to cricket, return a joke stating that it's out of context. "
                + "Return only a valid JSON with key 'content'.";

        // Send prompt to the AI model
        ChatResponse cricketResponse = chatModel.call(new Prompt(promptString));

        // Cast output to AssistantMessage to access getContent()
        AssistantMessage message = (AssistantMessage) cricketResponse.getResult().getOutput();
        String responseString = message.getContent(); // Get response text from AssistantMessage

        // Convert JSON string to Java object
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(responseString, CricketResponse.class);
    }

    /**
     * Load text file from classpath as a string (e.g., prompt templates)
     */
    public String loadPromptTemplate(String fileName) throws IOException {
        Path filePath = new ClassPathResource(fileName).getFile().toPath(); // Find resource file
        return Files.readString(filePath); // Read file content
    }

    /**
     * Replace placeholders like {key} with real values in a prompt template
     */
    public String putValuesInPromptTemplate(String template, Map<String, String> variables) {
        for (Map.Entry<String, String> entry : variables.entrySet()) {
            template = template.replace("{" + entry.getKey() + "}", entry.getValue()); // Simple string replace
        }
        return template;
    }

    /**
     * Generate image URLs from a textual prompt using OpenAI image generation
     */
    public List<String> generateImages(String imageDesc, int numbers) throws IOException {
        // Load prompt template from resources
        String template = this.loadPromptTemplate("prompts/image_bot.txt");

        // Replace variables in template
        String promptString = this.putValuesInPromptTemplate(template, Map.of("description", imageDesc));

        // Call OpenAI's image generation with options
        ImageResponse imageResponse = imageModel.call(
                new ImagePrompt(promptString, OpenAiImageOptions.builder()
                        .model("dall-e-2")
                        .N(numbers) // Number of images to generate
                        .height(512)
                        .width(512)
                        .quality("standard")
                        .build())
        );

        // Extract image URLs from the response
        return imageResponse.getResults().stream()
                .map(result -> result.getOutput().getUrl())
                .collect(Collectors.toList());
    }
}

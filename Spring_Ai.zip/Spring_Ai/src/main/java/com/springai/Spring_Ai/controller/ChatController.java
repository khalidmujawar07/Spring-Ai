package com.springai.Spring_Ai.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.springai.Spring_Ai.payload.CricketResponse;
import com.springai.Spring_Ai.service.ChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/v1/chat")
public class ChatController {

    @Autowired
    private ChatService chatService;

    /**
     * Basic chat endpoint (non-streaming)
     */
    @GetMapping
    public ResponseEntity<String> generateResponse(@RequestParam("inputText") String inputText) {
        String responseText = chatService.generateResponse(inputText);
        return ResponseEntity.ok(responseText);
    }

    /**
     * Streaming chat endpoint using Server-Sent Events (Flux)
     */
    @GetMapping("/stream")
    public Flux<String> streamResponse(@RequestParam("inputText") String inputText) {
        return chatService.streamResponse(inputText);
    }

    /**
     * Cricket Q&A bot endpoint that returns structured JSON response
     */
    @GetMapping("/cricketbot")
    public ResponseEntity<CricketResponse> getCricketResponse(@RequestParam("inputText") String inputText)
            throws JsonProcessingException {
        CricketResponse cricketResponse = chatService.generateCricketResponse(inputText);
        return ResponseEntity.ok(cricketResponse);
    }

    /**
     * Image generation endpoint using AI model (DALL·E or equivalent)
     */
    @GetMapping("/images")
    public List<String> generateImages(
            @RequestParam("imageDescription") String imageDesc,
            @RequestParam(value = "numberOfImages", required = false, defaultValue = "2") int numbers
    ) throws IOException {
        return chatService.generateImages(imageDesc, numbers);
    }
}

package com.springai.Spring_Ai.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

//@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CricketResponse {
        private String content;

        public CricketResponse(String content) {
                this.content = content;
        }

        public String getContent() {
                return content;
        }

        public void setContent(String content) {
                this.content = content;
        }

        @Override
        public String toString() {
                return "CricketResponse{" +
                        "content='" + content + '\'' +
                        '}';
        }
}
